﻿namespace CarShop.DTO
{
    public class ReserveCarDto
    {
        public int CarId { get; set; }
        public string DateFrom { get; set; }
        public string DateTo { get; set; }
        public int CarShopId { get; set; }
    }
}
