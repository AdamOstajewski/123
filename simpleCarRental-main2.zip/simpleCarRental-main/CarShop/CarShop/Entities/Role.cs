﻿using Microsoft.AspNetCore.Identity;

namespace CarShop.Entities
{
    public  class Role : IdentityRole<int>
    {

    }
}
